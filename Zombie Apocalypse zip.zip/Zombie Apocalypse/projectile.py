import math

class Projectile:
    def __init__(self, canvas, x=0, y=0, angle=0):
        """Class that creats a bullet

        Args:
            canvas (_type_): send in where you want everything to be outputted
            x (int, optional): sets the xpos of the bullet. Defaults to 0.
            y (int, optional): sets the ypos of the bullet. Defaults to 0.
            angle (int, optional): sets the angle of the bullet. Defaults to 0.
        """
        self.__canvas = canvas
        self.__size = 10
        self.__x = x - (self.__size // 2)
        self.__y = y - (self.__size // 2)
        self.__angle = angle
        self.__interval = 100
        self.__firing = None
        self.__output = canvas.create_oval(self.__x, self.__y, self.__x + self.__size, self.__y + self.__size, fill='red')
    
    def fire(self, interval=100):
        """creates a timer to move the bullet

        Args:
            interval (int, optional): After how many milliseconds should the bullet move. Defaults to 100.
        """
        self.__interval = interval
        self.__firing = self.__canvas.after(interval, self.fire)
        self.move()

    def move(self):
        """moves the bullet coexisting with fire
        """
        self.__x += 10 * math.cos(self.__angle)
        self.__y += 10 * math.sin(self.__angle)
        self.__update()

    def getBottom(self):
        """gives the user the bottom of the bullet

        Returns:
            int: the bottom of the object
        """
        return self.__x + self.__size
    
    def getTop(self):
        """gives the user the top of the bullet

        Returns:
            int: the top of the object
        """
        return self.__y
    
    def getRight(self):
        """gives the user the right value of the bullet

        Returns:
            int: the right of the object
        """
        return self.__x + self.__size
    
    def getLeft(self):
        """gives the user the left value of the bullet

        Returns:
            int: the left of the object
        """
        return self.__x
    
    def dispose(self):
        """deletes the bullet from the screen
        """
        self.__canvas.coords(self.__output, 2000, 2000, self.__x + self.__size, self.__y + self.__size)
        self.__canvas.delete(self.__output)
    
    def __update(self):
        """updates the coordinates of the bullet
        """
        self.__canvas.coords(self.__output, self.__x, self.__y, self.__x + self.__size, self.__y + self.__size)

    def getBounds(self):
        """gets the bounds of the object; the sides

        Returns:
            int: the side specified
        """
        x1 = self.__canvas.bbox(self.__output)[0] # Left side
        y1 = self.__canvas.bbox(self.__output)[1] # Top side
        x2 = self.__canvas.bbox(self.__output)[2] # Right side
        y2 = self.__canvas.bbox(self.__output)[3] # Bottom side
        bounds = [x1, y1, x2, y2]
        return bounds

    top = property(getTop)
    right = property(getRight)
    bottom = property(getBottom)
    left = property(getLeft)