from PIL import ImageTk, Image
from zombie import Direction
from tkinter import PhotoImage
import math

class Player:
    def __init__(self, canvas, x=0, y=0, angle=0):
        """creates the player

        Args:
            canvas (_type_): send in where you want everything to be outputted
            x (int, optional): sets the xpos of the object. Defaults to 0.
            y (int, optional): sets the ypos of the object. Defaults to 0.
            angle (int, optional): sets the angle of the object. Defaults to 0.
        """
        self.__pilImage = Image.open('images/player.png')
        self.__imgPlayer = ImageTk.PhotoImage(self.__pilImage)
        self.__pilImage1 = Image.open('images/dead_player.png')
        self.__deadPlayer = ImageTk.PhotoImage(self.__pilImage1)
        self.__direction = Direction.EAST
        self.__canvas = canvas
        self.__x = x
        self.__y = y
        self.__angle = angle
        self.__width = self.__imgPlayer.width()
        self.__height = self.__imgPlayer.height()
        self.__gunoriginx = self.__x + (self.__width // 2)
        self.__gunoriginy = self.__y
        self.__gunx = self.__gunoriginx
        self.__guny = self.__gunoriginy
        self.__output = self.__canvas.create_image(self.__x, self.__y, image=self.__imgPlayer, anchor='c')
        self.__update()

    def setAngle(self, angle):
        """sets the angle of the object by rotating

        Args:
            angle (int): ets the angle of the image object
        """
        self.__angle = angle
        imgrotated = self.__pilImage.rotate(self.__angle, Image.BICUBIC,True)
        self.__width = imgrotated.width
        self.__height = imgrotated.height
        self.__gunoriginx = self.__x + (self.__width // 2)
        self.__gunoriginy = self.__y
        self.__gunx = round(math.cos(math.radians(self.__angle)) *(self.__gunoriginx - self.__x) - math.cos(math.radians(self.__angle)) * (self.__gunoriginy - self.__y) + self.__x, 5)
        self.__guny = abs(round(math.sin(math.radians(self.__angle)) *(self.__gunoriginx - self.__x) + math.cos(math.radians(self.__angle)) * (self.__gunoriginy - self.__y) - self.__y, 5))
        self.__imgPlayer = ImageTk.PhotoImage(imgrotated)
        self.__update()
        
    def move(self, xpixels=0, ypixels=0):
        """moves the object given the number of pixels

        Args:
            xpixels (int, optional): the number of xpixels the user wants to move. Defaults to .
            ypixels (int, optional): the number of ypixels the user wants to move. Defaults to .
        """
        self.__y += ypixels
        self.__x += xpixels
        self.__gunoriginx = self.__x + (self.__width // 2)
        self.__gunoriginy = self.__y
        self.__gunx = round(math.cos(math.radians(self.__angle)) *(self.__gunoriginx - self.__x) - math.cos(math.radians(self.__angle)) * (self.__gunoriginy - self.__y) + self.__x, 5)
        self.__guny = abs(round(math.sin(math.radians(self.__angle)) *(self.__gunoriginx - self.__x) + math.cos(math.radians(self.__angle)) * (self.__gunoriginy - self.__y) - self.__y, 5))
        self.__update()
    
    def movediagonal(self, xpixels=3, ypixels=3):
        """moves the object diagonally given the number of pixels

        Args:
            xpixels (int, optional): the number of xpixels the user wants to move. Defaults to 3.
            ypixels (int, optional): the number of ypixels the user wants to move. Defaults to 3.
        """
        if self.__angle <= 90:
            self.__x += math.cos(self.__angle) * xpixels
            self.__y -= math.sin(self.__angle) * ypixels
        elif self.__angle >=90 and self.__angle <=180:
            self.__x += math.cos(self.__angle) * xpixels
            self.__y += math.cos(self.__angle) * ypixels
        elif self.__angle >=180 and self.__angle <=270:
            self.__x -= math.cos(self.__angle) *xpixels
            self.__y -= math.sin(self.__angle) * ypixels
        elif self.__angle >=270 and self.__angle <=360:
            self.__x += math.cos(self.__angle) * xpixels
            self.__y += math.sin(self.__angle) * ypixels
        self.__gunoriginx = self.__x + (self.__width // 2)
        self.__gunoriginy = self.__y
        self.__gunx = round(math.cos(math.radians(self.__angle)) *(self.__gunoriginx - self.__x) - math.cos(math.radians(self.__angle)) * (self.__gunoriginy - self.__y) + self.__x, 5)
        self.__guny = abs(round(math.sin(math.radians(self.__angle)) *(self.__gunoriginx - self.__x) + math.cos(math.radians(self.__angle)) * (self.__gunoriginy - self.__y) - self.__y, 5))
        self.__update()

    def getAngle(self):
        """gives the angle of the object

        Returns:
            int: the angle of the object
        """
        return self.__angle

    def gunPoint(self):
        return (self.__gunx, self.__guny)
        
    def getWidth(self):
        """gives the user the width of the image object

        Returns:
            int: the width of the image object
        """
        return self.__width
    
    def getHeight(self):
        """gives the user the height of the image object

        Returns:
            int: the height of the image object
        """
        return self.__height
    
    def getX(self):
        """gives the user the xpos of the image object

        Returns:
            int: the xpos of the image object
        """
        return self.__x
    
    def getY(self):
        """gives the user the ypos of the image object

        Returns:
            int: the ypos of the image object
        """
        return self.__y
    
    def getDirection(self):
        return self.__direction

    def setX(self, x):
        """sets the xpos of the object

        Args:
            x (int): the desires x position for the object
        """
        self.__x = x
        self.__update()
    
    def setY(self, y):
        """sets the ypos of the object

        Args:
            y (int): the desires y position for the object
        """
        self.__y = y
        self.__update()

    def getLeft(self):
        """gives the user the left value of the image object

        Returns:
            int: the left of the object
        """
        return self.__x - (self.width / 2)

    def getRight(self):
        """gives the user the right value of the image object

        Returns:
            int: the right of the object
        """
        return self.__x + (self.__width / 2)
    
    def getBottom(self):
        """gives the user the bottom value of the image object

        Returns:
            int: the bottom of the object
        """
        return self.__y + (self.__height / 2)

    def getTop(self):
        """gives the user the top value of the image object

        Returns:
            int: the top of the object
        """
        return self.__y - (self.__height / 2)

    def dead(self):
        """shows the image of the dead object 
        """
        imgrotated = self.__pilImage1.rotate(self.__angle, Image.BICUBIC,True)
        self.__width = imgrotated.width
        self.__height = imgrotated.height
        self.__deadPlayer = ImageTk.PhotoImage(imgrotated)
        self.__canvas.itemconfig(self.__output, image=self.__deadPlayer, anchor='c')

    def __update(self):
        """updates the coordinates of the bullet
        """
        self.__canvas.itemconfig(self.__output, image=self.__imgPlayer, anchor='c')
        self.__canvas.coords(self.__output, self.__x, self.__y)

    def getBounds(self):
        """gets the bounds of the object; the sides

        Returns:
            int: the side specified
        """
        x1 = self.__canvas.bbox(self.__output)[0] + 30 # Left side
        y1 = self.__canvas.bbox(self.__output)[1] + 30# Top side
        x2 = self.__canvas.bbox(self.__output)[2] - 30 # Right side
        y2 = self.__canvas.bbox(self.__output)[3] - 30# Bottom side
        bounds = [x1, y1, x2, y2]
        return bounds

    angle = property(getAngle, setAngle)
    width = property(getWidth)
    height = property(getHeight)
    x = property(getX, setX)
    y = property(getY, setY)
    right = property(getRight)
    left = property(getLeft)
    bottom = property(getBottom)
    top = property(getTop)