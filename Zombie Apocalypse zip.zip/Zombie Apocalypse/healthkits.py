from PIL import ImageTk, Image
from zombie import Direction

class HealthKits:
    def __init__(self, canvas, x=0, y=0):
        """creates the healthkits

        Args:
            canvas (_type_): send in where you want everything to be outputted
            x (int, optional): sets the xpos of the object. Defaults to 0.
            y (int, optional): sets the ypos of the object. Defaults to 0.
        """
        self.__pilImage = Image.open('images/first_aid.png')
        self.__imgHealthKit = ImageTk.PhotoImage(self.__pilImage)
        self.__x = x
        self.__y = y
        self.__canvas = canvas
        self.__x = x
        self.__y = y
        self.__width = self.__imgHealthKit.width()
        self.__height = self.__imgHealthKit.height()
        self.__output = self.__canvas.create_image(self.__x, self.__y, image=self.__imgHealthKit, anchor='c')
        self.__update()

    def getWidth(self):
        """gives the user the width of the image object

        Returns:
            int: the width of the image object
        """
        return self.__width
    
    def getHeight(self):
        """gives the user the height of the image object

        Returns:
            int: the height of the image object
        """
        return self.__height
    
    def getX(self):
        """gives the user the xpos of the image object

        Returns:
            int: the xpos of the image object
        """
        return self.__x
    
    def getY(self):
        """gives the user the ypos of the image object

        Returns:
            int: the ypos of the image object
        """
        return self.__y
    
    def setX(self, x):
        """sets the xpos of the object

        Args:
            x (int): the desired x position for the object
        """
        self.__x = x
        self.__update()
    
    def setY(self, y):
        """sets the ypos of the object

        Args:
            y (int): the desires y position for the object
        """
        self.__y = y
        self.__update()

    def getRight(self):
        """gives the user the right value of the object

        Returns:
            int: the right of the object
        """
        return self.__x + self.__width
    
    def getBottom(self):
        """gives the user the bottom value of the object

        Returns:
            int: the bottom of the object
        """
        return self.__y + self.__height

    def getTop(self):
        """gives the user the top value of the object

        Returns:
            int: the top of the object
        """
        return self.__y - (self.__height // 2)
    
    def __update(self):
        """updates the coordinates of the healthkit
        """
        self.__canvas.coords(self.__output, self.__x, self.__y)
        self.__canvas.itemconfig(self.__output, image=self.__imgHealthKit, anchor='c')

    def getBounds(self):
        """gets the bounds of the object; the sides

        Returns:
            int: the side specified
        """
        x1 = self.__canvas.bbox(self.__output)[0] # Left side
        y1 = self.__canvas.bbox(self.__output)[1] # Top side
        x2 = self.__canvas.bbox(self.__output)[2] # Right side
        y2 = self.__canvas.bbox(self.__output)[3] # Bottom side
        bounds = [x1, y1, x2, y2]
        return bounds