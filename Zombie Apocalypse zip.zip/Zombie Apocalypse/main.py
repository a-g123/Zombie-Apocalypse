# Importing classes used for the program
from tkinter import Tk, Canvas, Toplevel, messagebox
from PIL import ImageTk, Image
import pyglet
from player import Player
import math
from zombie import Zombie
from projectile import Projectile
import random
from healthkits import HealthKits
import pygame

# initilizing the sounds that would be used in the game
pygame.mixer.init()
pygame.mixer.music.load('bg_music.wav')
pygame.mixer.music.set_volume(0.3)
collectkitsound = pygame.mixer.Sound('med.wav')
hitsound = pygame.mixer.Sound('grunt.wav')

#If the user clicks the close button they will be prompted to ensure they want to exit
def close_window():
    #music will stop
    pygame.mixer.music.pause()
    answer = messagebox.askyesno('Zombie Apocalypse', 'Are you sure you want to exit?')
    if answer == True:
        messagebox.showinfo('Zombie Apocalypse', 'Thank you for playing Zombie Apocalypse!')
        exit()
    else:
        #if they don't want to leave music will continue
        pygame.mixer.music.unpause()

#Timer for the number of seconds remaining in the game
def timer():
    global seconds, kills, kits, zombiesid, timerid, zombie_timerid, kcollisionid, zcollisionid, gameend
    canvas.itemconfig(outputtime, text=f'TIME:  {seconds}')
    timerid = root.after(1000, timer)
    #when the timer reaches 0 the game has ended
    if seconds == 0:
        #indicates how the game ended so the correct message appears
        gameend = 'time'
        gameover()
    #after every second the time goes down
    seconds -= 1

#checks the number of times the gameover function was called in one game
go = 0
#the gameover function stops all the timers
def gameover():
    global timerid, zombie_timerid, zombiesid, bcollisionid, kcollisionid, zcollisionid, zombielist, bulletlist, gameend, go
    if go == 0:
        #The music stops
        pygame.mixer.music.stop()
        bulletlist.clear()
        #timers cancel
        root.after_cancel(timerid)
        root.after_cancel(zcollisionid)
        zcollisionid = None
        if zombiesid != None:
            root.after_cancel(zombiesid)
            zombiesid = None
        if zombie_timerid != None:
            root.after_cancel(zombie_timerid)
            zombie_timerid = None
        root.after_cancel(kcollisionid)
        kcollisionid = None
        if bcollisionid != None:
            root.after_cancel(bcollisionid)
            bcollisionid = None
        # checks how the game ends and sends it to the correct message spot
        if gameend == 'time':
            timesup()
        elif gameend == 'collide':
            collided()
    go += 1

#if the zombie and player collided it will be brought here
def collided():
    global over
    # the keys stop working
    root.unbind('<KeyPress>')
    root.unbind('<Motion>')
    root.unbind('<Button>')
    #gameover image appears and stays this way for 3 seconds until the stats of the game are shown
    over = canvas.create_image(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, image=imgOver)
    root.after(3000, stats)

#shows the user stats and asks if they want to play again
def stats():
    answer = messagebox.askyesno('Game Over', f'GAME STATS\n\nKILLS:\t\t{kills}\nHEALTH KITS:\t{kits}\n\nWould you like to play again?')
    if answer == True:
        # if the user wants to play again they will be taken the the restart function which will restart the game
        restart()
    else:
        messagebox.showinfo('Zombie Apocalypse', 'Thankyou for playing!')
        exit()

#shows the user stats and asks if they want to play again
def timesup():
    #if the user picks up all the med kits they win
    if kits >= 10:
        answer = messagebox.askyesno('Game Over', f'Congratulations! You saved the world from the Zombie Apocalypse.\n\nGAME STATS\n\nKILLS:\t\t{kills}\nHEALTH KITS:\t{kits}\n\nWould you like to play again?')
        if answer == True:
        # if the user wants to play again they will be taken the the restart function which will restart the game
            restart()
        else:
            messagebox.showinfo('Zombie Apocalypse', 'Thankyou for playing!')
            exit()
    #otherwise if the user doesn't pick up all the kits they lose
    else:
        answer = messagebox.askyesno('Game Over', f'Time\'s up!\nYou failed to saved the world from the Zombie Apocalypse.\n\nGAME STATS\n\nKILLS:\t\t{kills}\nHEALTH KITS:\t{kits}\n\nWould you like to play again?')
        if answer == True:
        # if the user wants to play again they will be taken the the restart function which will restart the game
            restart()
        else:
            messagebox.showinfo('Zombie Apocalypse', 'Thankyou for playing!')
            exit()

#the fucntion restarts the game by resetting the screen and making all the values as they started
def restart():
    global gameend, go, zombielist, bulletlist, kitlist, kills, seconds, kits, timerid, bcollisionid, zcollisionid, zombiesid, zombie_timerid, kcollisionid, p, bgoutput, over, outputkits, outputkills, outputtime, numzom
    bgoutput = canvas.create_image(backgroundx, backgroundy, image=picBackground, anchor='nw')
    outputkills = canvas.create_text(SCREEN_WIDTH * 0.15, int(canvas_splash.winfo_reqheight() * 0.05), text=f'KILLS:  {kills}', font=("Zombie_Holocaust", 30), fill='red')
    outputtime = canvas.create_text(SCREEN_WIDTH * 0.5, int(canvas_splash.winfo_reqheight() * 0.05), text=f'TIME:  {seconds}', font=("Zombie_Holocaust", 30), fill='red')
    outputkits = canvas.create_text(SCREEN_WIDTH * 0.85, int(canvas_splash.winfo_reqheight() * 0.05), text=f'KITS:  {kits}', font=("Zombie_Holocaust", 30), fill='red')
    for b in bulletlist:
        b.dispose()
        bulletlist.remove(b)
    zombielist.clear()
    kitlist.pop(0)
    kitlist = [] 
    bulletlist = []
    zombielist = []
    gameend = None
    timerid = None
    bcollisionid = None
    zcollisionid = None
    zombiesid = None
    zombie_timerid = None
    kcollisionid = None
    canvas.delete(over)
    go = 0
    numzom = 0
    kills, seconds, kits = 0, 60, 0
    canvas.itemconfig(outputkills, text=f'KILLS:  {kills}')
    canvas.itemconfig(outputkits, text=f'TIME:  {seconds}')
    canvas.itemconfig(outputkits, text=f'KITS:  {kits}')
    p = Player(canvas, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
    #rebinding the keyboard and mouse to the window
    root.bind('<KeyPress>', onkeypress)
    root.bind('<Motion>', onmousemove)
    root.bind('<Button>', onmousepress)
    #starting the song again
    pygame.mixer.music.play(-1)
    #calling the functions/timers that will start the game and call the other fucntion
    zombiesid = root.after(3500, zombies)
    timerid = root.after(1000, timer)
    health()

#checking the number of times the space key is pressed
space = 0
def onkeypress(event):
    global space
    #if the space key is pressed the splash screen will disapear
    if event.char == ' ':
        close_splashscreen()
        if space == 0:
            #the music will start and a call will be made to the functions/timers that will start the game and call the other fucntion
            pygame.mixer.music.play(-1)
            zombies()
            timer()
            health()
        space += 1
    #if the z key is pressed the player is moving diagonally 225 degrees
    elif event.char == 'z' or event.keysym == '1':
        p.setAngle(225)
        p.movediagonal(10, 10)
        #checking the player position to move the bg
        if p.y > 50 and p.y < 150 or p.y > 450 and p.y < 550:
            canvas.move(bgoutput, 0, -25)
            for z in zombielist:
                z.setY(z.getY() - 25)
            kitlist[0].setY(kitlist[0].getY() - 25)
        #makes sure the player doesn't go off the screen in the y-axis
        if p.y >= 550:
            p.setY(550)
        elif p.y < 105:
            p.setY(105)
        canvas.focus_set()
    #if the x key is pressed the player moves straight down
    elif event.char == 'x' or event.keysym == '2':
        p.setAngle(270)
        p.move(0, 10)
        #checking the player position to move the bg
        if p.y > 50 and p.y < 150 or p.y > 450 and p.y < 550:
            canvas.move(bgoutput, 0, -25)
            for z in zombielist:
                z.setY(z.getY() - 25)
            kitlist[0].setY(kitlist[0].getY() - 25)
        #makes sure the player doesn't go off the screen in the y-axis
        if p.y >= 550:
            p.setY(550)
        elif p.y < 105:
            p.setY(105)
        canvas.focus_set()
    #if the c is pressed the player will move diagonally 315 degrees
    elif event.char == 'c' or event.keysym == '3':
        p.setAngle(315)
        p.movediagonal(10, 10)
        #checking the player position to move the bg
        if p.y > 50 and p.y < 150 or p.y > 450 and p.y < 550:
            canvas.move(bgoutput, 0, -25)
            for z in zombielist:
                z.setY(z.getY() - 25)
            kitlist[0].setY(kitlist[0].getY() - 25)
        #makes sure the player doesn't go off the screen in the y-axis
        if p.y >= 550:
            p.setY(550)
        elif p.y < 105:
            p.setY(105)
    #if the a key is pressed the player will move to the left
    elif event.char == 'a' or event.keysym == '4':
        p.setAngle(180)
        p.move(-10, 0)
        #checking the player position to move the bg
        if p.x > 600 and p.x < 700 or p.x > 100 and p.x < 200:
            canvas.move(bgoutput, 5, 0)
            for z in zombielist:
                z.setX(z.getX() + 5)
            kitlist[0].setX(kitlist[0].getX() + 5)
        #makes sure the player doesn't go off the screen in the y-axis
        if p.y >= 550:
            p.setY(550)
        elif p.y < 105:
            p.setY(105)
        canvas.focus_set()
    #if the d key is pressed the player will move to the right
    elif event.char == 'd' or event.keysym == '6':
        p.setAngle(0)
        p.move(10, 0)
        #checking the player position to move the bg
        if p.x > 600 and p.x < 700 or p.x > 100 and p.x < 200:
            canvas.move(bgoutput, -5, 0)
            for z in zombielist:
                z.setX(z.getX() - 5)
            kitlist[0].setX(kitlist[0].getX() - 5)
        #makes sure the player doesn't go off the screen in the y-axis
        if p.y >= 550:
            p.setY(550)
        elif p.y < 105:
            p.setY(105)
        canvas.focus_set()
    #if the q key is pressed the playr will move diagonally 135 degrees
    elif event.char == 'q' or event.keysym == '7':
        p.setAngle(135)
        p.movediagonal(10, 10)
        #checking the player position to move the bg
        if p.y > 105 and p.y < 175 or p.y > 450 and p.y < 550:
            canvas.move(bgoutput, 0, 25)
            for z in zombielist:
                z.setY(z.getY() + 25)
            kitlist[0].setY(kitlist[0].getY() + 25)
        #makes sure the player doesn't go off the screen in the y-axis
        if p.y >= 550:
            p.setY(550)
        elif p.y < 105:
            p.setY(105)
    #if the w key is pressed the the player will move straight up
    elif event.char == 'w' or event.keysym == '8':
        p.setAngle(90)
        p.move(0, -10)
        #checking the player position to move the bg
        if p.y > 105 and p.y < 175 or p.y > 450 and p.y < 550:
            canvas.move(bgoutput, 0, 25)
            for z in zombielist:
                z.setY(z.getY() + 25)
            kitlist[0].setY(kitlist[0].getY() + 25)
        #makes sure the player doesn't go off the screen in the y-axis
        if p.y >= 550:
            p.setY(550)
        elif p.y < 105:
            p.setY(105)
    elif event.char == 'e' or event.keysym == '9':
        p.setAngle(45)
        p.movediagonal(10, 10)
        if p.y > 105 and p.y < 175 or p.y > 450 and p.y < 550:
            canvas.move(bgoutput, 0, 25)
            for z in zombielist:
                z.setY(z.getY() + 25)
            kitlist[0].setY(kitlist[0].getY() + 25)
        if p.y >= 550:
            p.setY(550)
        elif p.y < 105:
            p.setY(105)
#makes sure the player doesn't go off the screen in the x-axis
    if p.x - (p.width / 2) <= 0:
        p.setX(p.width / 2)
    elif p.x + p.width / 2 >= 795:
        p.setX(canvas.winfo_width() - (p.width/2))

def close_splashscreen():
    root.deiconify()
    splash_screen.withdraw()

#when the mouse moves the player will rotate with it 
def onmousemove(event):
    dx = event.x - p.x
    dy = p.y - event.y
    p.angle = math.degrees(math.atan2(dy, dx))  

#when the left mouse key is pressed a bullet will be made and will fire
def onmousepress(event):
    if event.num == 1:
        bulletlist.append(Projectile(canvas, p.gunPoint()[0],p.gunPoint()[1], math.atan2(event.y - p.y, event.x -p.x)))
        bulletlist[len(bulletlist) - 1].fire(10)
        if len(bulletlist) == 1:
            #calls the bullet collision function to check if the bullet collides with the zombie
            bcollision()

#the bullet collision function: checks if the zombie and bullet collide
def bcollision():
    global kills, timerid, zombiesid, kcollisionid, zcollisionid, zombie_timerid, bcollisionid, seconds
    #timer starts
    bcollisionid = root.after(1, bcollision)
    if seconds == -1:
        bulletlist.clear()
    for b in bulletlist:
        #checks if the bullet left the screen: if it did it will be removed
        if b.right <= 0 or b.left >= imgBackground.width or b.bottom <= 0 or b.top >= imgBackground.height:
            b.dispose()
            bulletlist.remove(b)
        else:
            #checks for zombie and bullet collision
            for b in bulletlist:
                for z in zombielist:
                    if b in bulletlist:
                        if z.right >= b.left and z.left <= b.right:
                            if z.bottom >= b.top and z.top <= b.bottom:
                                #if there is collision the sound effect will play, the bullet will be removed and the zombie will be dead
                                hitsound.play()
                                b.dispose()
                                bulletlist.remove(b)
                                z.dead()
                                zombielist.remove(z)
                                #the kills will go up
                                kills += 1
                                canvas.itemconfig(outputkills, text=f'KILLS:  {kills}')

#variable makes sure the move function and collide function are only called once
numzom = 0   
#the fucntion creates zombies
def zombies():
    global zombiesid, seconds, numzom
    #starts the zombie timer: makes a zombie after 3 and a half seconds
    zombiesid = root.after(3500, zombies)
    if seconds == -1:
        root.after_cancel(zombiesid)
        zombiesid = None
    #only 18 zombies can appear on the screen at a time
    if len(zombielist) <= 18:
        #ensures the zombies only come from the sides
        randomy = [-70, 610]
        random.shuffle(randomy)
        zombielist.append(Zombie(canvas, zombieimages, deadzombie))
        zombielist[len(zombielist)-1].setLocation(random.randint(0, SCREEN_WIDTH), randomy[0])
        if numzom == 0:
            #calls the functions to move the zombie and another to check for collision
            zombie_timer()
            zcollision()
    numzom += 1

#the function checks for collision between the zombie and player
def zcollision():
    global timerid, zombiesid, kcollisionid, zcollisionid, zombie_timerid, bcollisionid, gameend
    #starts the timer
    zcollisionid = root.after(1, zcollision)
    for z in zombielist:
        if z.getBounds()[2] >= p.getBounds()[0] and z.getBounds()[0] <= p.getBounds()[2]:
            if z.getBounds()[3] >= p.getBounds()[1] and z.getBounds()[1] <= p.getBounds()[3]:
                #if collision the dead player image will appear, the sound effect will play and will call the game over function
                p.dead()
                hitsound.play()
                #indicates how the game ended so the correct message appears
                gameend = 'collide'
                gameover()

#the fucntion moves the zombie to follow the player
def zombie_timer():
    global zombie_timerid, seconds
    #starting the moving timer
    zombie_timerid = root.after(50, zombie_timer)
    if seconds == 0:
        root.after_cancel(zombie_timerid)
        zombie_timerid = None
    for z in zombielist:
        #calculating the angle the zombie has to move in to get to the player
        posx = p.x - z.getX()
        posy = p.y - z.getY()
        a = math.atan2(posy, posx)
        z.follow(p.x, p.y, a)

#the fucntion creates the medkits
def health():
    #the medkits only appear when there are none on the screen
    if len(kitlist) == 0:
        width = random.randint(30, SCREEN_WIDTH - 30)
        height = random.randint(105, SCREEN_HEIGHT - 30)
        kitlist.append(HealthKits(canvas, width, height))
    #calls a function to check for collision between the kit and the player
    kcollision()

#the function checks for the collision between the player and medkit
def kcollision():
    global kits, timerid, zombiesid, kcollisionid, zcollisionid, zombie_timerid, bcollisionid, gameend
    #starts the timer
    kcollisionid = root.after(1, kcollision)
    if len(kitlist) == 1:
        if p.getBounds()[2] >= kitlist[0].getBounds()[0] and p.getBounds()[0] <= kitlist[0].getBounds()[2]:
            if p.getBounds()[3] >= kitlist[0].getBounds()[1] and p.getBounds()[1] <= kitlist[0].getBounds()[3]:
                #if there is collsion the sound effect comes up
                collectkitsound.play()
                kitlist.pop(0)
                kits += 1
                canvas.itemconfig(outputkits, text=f'KITS:  {kits}')
                #if 10 kits are collected the game has finished and the user wins
                if kits == 10:
                    #indicates how the game ended so the correct message appears
                    gameend = 'time'
                    gameover()
                #if not all kits have been collected a call is made to create kits
                else:
                    health()
    else:
        health()

#The interface:
SCREEN_WIDTH, SCREEN_HEIGHT, TOP_BORDER = 800, 600, 65
root = Tk()
root.title('Zombie Apocalypse')
root.protocol('WM_DELETE_WINDOW', close_window)

#importing all the pictures
zombieimages = []
for index in range(16):
    zombieimages.append(f'images/zombie{index}.png')
deadzombie = []
deadzombie.append('images/dead_zombie.png')

imgBackground = Image.open('images/background.png')
picBackground = ImageTk.PhotoImage(imgBackground)
imgOver = ImageTk.PhotoImage(Image.open('images/game_over.png'))
pyglet.font.add_file("fonts/Zombie_Holocaust.ttf")

root.geometry(f'{SCREEN_WIDTH}x{SCREEN_HEIGHT}+{(root.winfo_screenwidth() - SCREEN_WIDTH) // 2}+{(root.winfo_screenheight() - SCREEN_HEIGHT) // 2}')

#Binding the the window to the keys and mouse
root.bind('<KeyPress>', onkeypress)
root.bind('<Motion>', onmousemove)
root.bind('<Button>', onmousepress)

backgroundx = (SCREEN_WIDTH - imgBackground.width) // 2
backgroundy = (SCREEN_HEIGHT - imgBackground.height) // 2

canvas = Canvas(root, width=SCREEN_WIDTH, height=SCREEN_HEIGHT)
canvas.pack()
bgoutput = canvas.create_image(backgroundx, backgroundy, image=picBackground, anchor='nw')
canvas.focus_set()

imgSplash = ImageTk.PhotoImage(imgBackground.resize((imgBackground.width // 2, imgBackground.height // 2)))
imgTitle = Image.open('images/zombie_apocalypse.png')
imgTitle = ImageTk.PhotoImage(imgTitle.resize((imgTitle.width // 2, imgTitle.height // 2)))
imgStart = ImageTk.PhotoImage(Image.open('images/start_game.png'))

splash_screen = Toplevel()
splash_screen.title('Zombie Apocalypse')
splash_screen.geometry(f'{imgSplash.width()}x{imgSplash.height()}+{(root.winfo_screenwidth() - imgSplash.width()) // 2}+{(root.winfo_screenheight() - imgSplash.height()) // 2}')
splash_screen.resizable(False, False)
splash_screen.bind('<KeyPress>', onkeypress)
splash_screen.protocol('WM_DELETE_WINDOW', close_splashscreen)

canvas_splash = Canvas(splash_screen, width=imgSplash.width(), height=imgSplash.height())
canvas_splash.create_image(0, 0, image=imgSplash, anchor='nw')
canvas_splash.create_image(canvas_splash.winfo_reqwidth() // 2, int(canvas_splash.winfo_reqheight() * 0.3), image=imgTitle, anchor='c')
canvas_splash.create_image(canvas_splash.winfo_reqwidth() // 2, int(canvas_splash.winfo_reqheight() * 0.6), image=imgStart, anchor='c')
canvas_splash.pack()

#setting the player to the center of the screen and different variables which will be used in the game
p = Player(canvas, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
bulletlist = []
zombielist = []
kitlist = []
bcollisionid = None
zcollisionid = None
zombiesid = None
zombie_timerid = None
kcollisionid = None
gameend = None
over = None

#outputting the initial kills, time left and kits collected
kills, seconds, kits = 0, 60, 0
outputkills = canvas.create_text(SCREEN_WIDTH * 0.15, int(canvas_splash.winfo_reqheight() * 0.05), text=f'KILLS:  {kills}', font=("Zombie_Holocaust", 30), fill='red')
outputtime = canvas.create_text(SCREEN_WIDTH * 0.5, int(canvas_splash.winfo_reqheight() * 0.05), text=f'TIME:  {seconds}', font=("Zombie_Holocaust", 30), fill='red')
outputkits = canvas.create_text(SCREEN_WIDTH * 0.85, int(canvas_splash.winfo_reqheight() * 0.05), text=f'KITS:  {kits}', font=("Zombie_Holocaust", 30), fill='red')

root.withdraw()
splash_screen.deiconify()

root.mainloop()