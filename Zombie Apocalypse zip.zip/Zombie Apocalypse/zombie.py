from enum import Enum
from PIL import Image, ImageTk
import math

class Direction(Enum):
    NORTH = 0
    EAST = 1
    SOUTH = 2
    WEST = 3

class Zombie:
    def __init__(self, canvas, img, imgdead, angle=0):
        """creates the zombies

        Args:
            canvas (_type_): send in where you want everything to be outputted
            img (_type_): send in the images you want uploaded
            imgdead (_type_): send in the images of the dead you want uploaded
            angle (int, optional): sets the angle of the object. Defaults to 0.
        """
        self.__canvas = canvas
        self.__imgfiles = img
        self.__pilImages = []
        self.__images = []
        for index in range(len(self.__imgfiles)):
            self.__pilImages.append(Image.open(self.__imgfiles[index]))
            self.__images.append(ImageTk.PhotoImage(Image.open(self.__imgfiles[index])))
        self.__deadfiles = imgdead
        self.__deadimage = []
        self.__deadimage.append(ImageTk.PhotoImage(Image.open(self.__deadfiles[0])))
        self.__index = 0
        self.__direction = Direction.EAST
        self.__x = 0
        self.__y = 0
        self.__angle = angle
        self.__width = self.__images[self.__index].width()
        self.__height = self.__images[self.__index].height()
        self.__currentimage = self.__canvas.create_image(self.__x, self.__y, image=self.__images[self.__index], anchor='nw')
    
    def move(self, xpixels=1, ypixels=0):
        """moves the object given the number of pixels

        Args:
            xpixels (int, optional): the number of xpixels the user wants to move. Defaults to 1.
            ypixels (int, optional): the number of ypixels the user wants to move. Defaults to 0.
        """
        self.__index += 1
        self.__y += ypixels
        self.__x += xpixels
        if self.__index == len(self.__images):
            self.__index = 0
        self.__canvas.itemconfig(self.__currentimage, image=self.__images[self.__index], anchor='nw')
        self.__canvas.coords(self.__currentimage, self.__x, self.__y)
        
    def getWidth(self):
        """gives the user the width of the image object

        Returns:
            int: the width of the image object
        """
        return self.__width

    def getHeight(self):
        """gives the user the height of the image object

        Returns:
            int: the heigt of the image object
        """
        return self.__height
    
    def getX(self):
        """gives the user the xpos of the image object

        Returns:
            int: the xpos of the image object
        """
        return self.__x
    
    def getY(self):
        """gives the user the ypos of the image object

        Returns:
            int: the ypos of the image object
        """
        return self.__y

    def getBottom(self):
        """gives the user the bottom value of the image object

        Returns:
            int: the bottom of the object
        """
        return self.__y + self.__height
    
    def getTop(self):
        """gives the user the top value of the image object

        Returns:
            int: the top of the object
        """
        return self.__y 
    
    def getRight(self):
        """gives the user the right value of the image object

        Returns:
            int: the right of the object
        """
        return self.__x + self.__width
    
    def getLeft(self):
        """gives the user the left value of the image object

        Returns:
            int: the left of the object
        """
        return self.__x

    def setX(self, x):
        """sets the xpos of the object

        Args:
            x (int): the desires x position for the object
        """
        self.__x = x
        self._update()
    
    def setY(self, y):
        """sets the ypos of the object

        Args:
            y (int): the desired y position for the object
        """
        self.__y = y
        self._update()

    def setLocation(self, x, y):
        """sets the x and y pos of the object

        Args:
            x (int): the desired x position for the object
            y (int): the desired y position for the object
        """
        self.setX(x)
        self.setY(y)

    def setAngle(self, angle):
        """sets the angle of the object by rotating

        Args:
            angle (int): ets the angle of the image object
        """
        self.__angle = angle
        imgrotated = self.__pilImages[self.__index].rotate(self.__angle, Image.BICUBIC, True)
        self.__width = imgrotated.width
        self.__height = imgrotated.height
        self.__images[self.__index] = ImageTk.PhotoImage(imgrotated)
        self._update()

    def getBounds(self):
        """gets the bounds of the object; the sides

        Returns:
            int: the side specified
        """
        x1 = self.__canvas.bbox(self.__currentimage)[0] + 10 # Left side
        y1 = self.__canvas.bbox(self.__currentimage)[1] + 10# Top side
        x2 = self.__canvas.bbox(self.__currentimage)[2] - 10# Right side
        y2 = self.__canvas.bbox(self.__currentimage)[3] - 10# Bottom side
        bounds = [x1, y1, x2, y2]
        return bounds

    def follow(self, playerx, playery, angle):
        """follows the coordinates given

        Args:
            playerx (int): the x value to follow
            playery (int): the y value to follow
            angle (int): the angle to move
        """
        self.__angle = angle
        imgrotated = self.__pilImages[self.__index].rotate(-(self.__angle * (180/math.pi)), Image.BICUBIC, True)
        self.__images[self.__index] = ImageTk.PhotoImage(imgrotated)
        self.__width = self.__images[self.__index].width()
        self.__height = self.__images[self.__index].height()

        # If player's x is greater than my x
        if playerx > self.getX():
            self.setX(self.getX() + 1)
        
        # If player's x is less than my x
        elif playerx < self.getX():
            self.setX(self.getX() - 1)
        
        # If player's y is greater than my y
        if playery < self.getY():
            self.setY(self.getY() - 1)
        
        elif playery > self.getY():
            self.setY(self.getY() + 1)
        
        if playerx  == self.getX() and playery == self.getY():
            self.__index = 0
            self.setY(self.getY() + 0)
            self.setX(self.getX() + 0)
        
        self._update()
        self.__index += 1
        if self.__index == len(self.__images) - 1:
            self.__index = 0

    def dead(self):
        """shows the image of the dead zombie 
        """
        self.__canvas.itemconfig(self.__currentimage, image=self.__deadimage[0])

    def _update(self):
        """updates the coordinates of the bullet
        """
        self.__canvas.coords(self.__currentimage, self.__x, self.__y)
        self.__canvas.itemconfig(self.__currentimage, image=self.__images[self.__index])

    def setDirection(self, dir):
        """sets the direction for the object

        Args:
            dir (enum): direction 
        """
        self.__direction = dir
        if self.__direction == Direction.EAST:
            self.__canvas.itemconfig(self.__currentimage, image=self.__images[self.__index])
        else:
            self.__canvas.itemconfig(self.__currentimage, image=self.__images[self.__index])


    right = property(getRight)
    left = property(getLeft)
    top = property(getTop)
    bottom = property(getBottom)
    x = property(setX, getX)
    y = property(setY, getY)